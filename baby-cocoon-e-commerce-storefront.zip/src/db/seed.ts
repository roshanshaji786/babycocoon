import { db } from "./index";
import { categories, products, reviews } from "./schema";

async function seed() {
  console.log("🌱 Seeding database...");

  // Clear existing data
  await db.delete(reviews);
  await db.delete(products);
  await db.delete(categories);

  // Insert categories
  const [newbornEssentials] = await db
    .insert(categories)
    .values({
      name: "Newborn Essentials",
      slug: "newborn-essentials",
      description: "Everything your newborn needs for a cozy start",
      image: "https://images.pexels.com/photos/12654853/pexels-photo-12654853.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      sortOrder: 1,
    })
    .returning();

  const [babyBedding] = await db
    .insert(categories)
    .values({
      name: "Baby Bedding",
      slug: "baby-bedding",
      description: "Soft and comfortable bedding for sweet dreams",
      image: "https://images.pexels.com/photos/4964488/pexels-photo-4964488.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      sortOrder: 2,
    })
    .returning();

  const [carryBeds] = await db
    .insert(categories)
    .values({
      name: "Carry Beds",
      slug: "carry-beds",
      description: "Portable and comfortable beds for on-the-go",
      image: "https://images.pexels.com/photos/33719889/pexels-photo-33719889.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      sortOrder: 3,
    })
    .returning();

  const [comboSets] = await db
    .insert(categories)
    .values({
      name: "Combo Sets",
      slug: "combo-sets",
      description: "Value packs with everything bundled together",
      image: "https://images.pexels.com/photos/4887156/pexels-photo-4887156.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      sortOrder: 4,
    })
    .returning();

  const [babyCradles] = await db
    .insert(categories)
    .values({
      name: "Baby Cradles",
      slug: "baby-cradles",
      description: "Gentle rocking cradles for peaceful sleep",
      image: "https://images.pexels.com/photos/4964372/pexels-photo-4964372.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      sortOrder: 5,
    })
    .returning();

  const [feedingPillows] = await db
    .insert(categories)
    .values({
      name: "Feeding Pillows",
      slug: "feeding-pillows",
      description: "Ergonomic pillows for comfortable feeding",
      image: "https://images.pexels.com/photos/4887110/pexels-photo-4887110.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      sortOrder: 6,
    })
    .returning();

  const [netBeds] = await db
    .insert(categories)
    .values({
      name: "Net Beds",
      slug: "net-beds",
      description: "Protected sleeping spaces with mosquito nets",
      image: "https://images.pexels.com/photos/14023459/pexels-photo-14023459.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      sortOrder: 7,
    })
    .returning();

  const [hoodedTowels] = await db
    .insert(categories)
    .values({
      name: "Hooded Towels",
      slug: "hooded-towels",
      description: "Adorable and absorbent towels for bath time",
      image: "https://images.pexels.com/photos/16222075/pexels-photo-16222075.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      sortOrder: 8,
    })
    .returning();

  const [jablasClothing] = await db
    .insert(categories)
    .values({
      name: "Jablas & Clothing",
      slug: "jablas-clothing",
      description: "Soft, breathable baby clothing for everyday wear",
      image: "https://images.pexels.com/photos/32386177/pexels-photo-32386177.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      sortOrder: 9,
    })
    .returning();

  const [muslinCollection] = await db
    .insert(categories)
    .values({
      name: "Muslin Collection",
      slug: "muslin-collection",
      description: "Premium muslin fabric products for delicate skin",
      image: "https://images.pexels.com/photos/8773748/pexels-photo-8773748.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      sortOrder: 10,
    })
    .returning();

  const [storageBasket] = await db
    .insert(categories)
    .values({
      name: "Storage Baskets",
      slug: "storage-baskets",
      description: "Organized storage solutions for baby essentials",
      image: "https://images.pexels.com/photos/4964374/pexels-photo-4964374.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      sortOrder: 11,
    })
    .returning();

  const [swaddlesWrappers] = await db
    .insert(categories)
    .values({
      name: "Swaddles & Wrappers",
      slug: "swaddles-wrappers",
      description: "Cozy wrapping solutions for newborns",
      image: "https://images.pexels.com/photos/11517555/pexels-photo-11517555.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      sortOrder: 12,
    })
    .returning();

  // ── Insert all products ──
  const productData = [
    // Combo Sets
    {
      name: "3 Pcs Newborn Combo - Pink Elephant",
      slug: "3-pcs-newborn-combo-pink-elephant",
      description:
        "This adorable 3-piece newborn combo set includes a soft carry bed, matching pillow, and cozy bolster set featuring a charming pink elephant print. Made from 100% pure cotton, this set is gentle on your baby's delicate skin. The carry bed provides a safe and comfortable sleeping space, while the pillow and bolsters offer perfect support. Ideal for newborns aged 0-6 months.",
      shortDescription: "Soft cotton carry bed, pillow & bolster set",
      price: "2850.00",
      compareAtPrice: "3299.00",
      categoryId: comboSets.id,
      images: [
        "https://images.pexels.com/photos/4887156/pexels-photo-4887156.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4887110/pexels-photo-4887110.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4887081/pexels-photo-4887081.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "100% Pure Cotton",
        "Soft & Breathable",
        "Machine Washable",
        "Hypoallergenic",
        "Includes Carry Bed, Pillow & Bolster",
      ],
      isFeatured: true,
      isBestseller: true,
      ageRange: "0-6 months",
      material: "100% Cotton",
      rating: "4.7",
      reviewCount: 128,
    },
    {
      name: "3 Pcs Combo - Blue Stars",
      slug: "3-pcs-combo-blue-stars",
      description:
        "Beautiful 3-piece combo set in a charming blue stars print. This set includes a padded sleeping mattress, a shaped baby pillow, and two side bolsters. The premium cotton fabric ensures maximum comfort while the attractive star pattern adds a touch of joy to your nursery. Perfect for gifting and everyday use.",
      shortDescription: "Mattress, pillow & bolster in blue stars print",
      price: "3250.00",
      compareAtPrice: "3599.00",
      categoryId: comboSets.id,
      images: [
        "https://images.pexels.com/photos/4964372/pexels-photo-4964372.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4964488/pexels-photo-4964488.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Premium Cotton Fabric",
        "Attractive Star Pattern",
        "Includes Mattress, Pillow & 2 Bolsters",
        "Lightweight & Portable",
        "Easy to Clean",
      ],
      isFeatured: true,
      isBestseller: false,
      ageRange: "0-6 months",
      material: "Cotton Blend",
      rating: "4.6",
      reviewCount: 95,
    },
    {
      name: "3 Pcs Combo - Garden Print",
      slug: "3-pcs-combo-garden-print",
      description:
        "A delightful 3-piece combo with a beautiful garden-themed print. Includes a quilted mattress, neck-support pillow, and bolster pair. Crafted from soft muslin cotton that becomes softer with every wash. The breathable fabric ensures your baby stays cool and comfortable throughout the day and night.",
      shortDescription: "Garden-print mattress, pillow & bolster set",
      price: "2850.00",
      compareAtPrice: "3299.00",
      categoryId: comboSets.id,
      images: [
        "https://images.pexels.com/photos/4887081/pexels-photo-4887081.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4887156/pexels-photo-4887156.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Muslin Cotton Fabric",
        "Gets Softer with Each Wash",
        "Quilted Mattress",
        "Neck-Support Pillow",
        "Breathable & Cool",
      ],
      isFeatured: false,
      isBestseller: true,
      ageRange: "0-6 months",
      material: "Muslin Cotton",
      rating: "4.8",
      reviewCount: 76,
    },
    {
      name: "4 Pcs Deluxe Combo Set",
      slug: "4-pcs-deluxe-combo-set",
      description:
        "Our premium 4-piece combo set includes a carry bed, gadda mattress, pillow, and bolster pair. This comprehensive set provides everything your newborn needs for comfortable rest. The high-quality cotton filling provides excellent cushioning while the outer fabric is soft and skin-friendly. Comes in a beautiful gift-ready packaging.",
      shortDescription: "Complete 4-piece carry bed, mattress, pillow & bolster",
      price: "4200.00",
      compareAtPrice: "4999.00",
      categoryId: comboSets.id,
      images: [
        "https://images.pexels.com/photos/4964488/pexels-photo-4964488.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4964372/pexels-photo-4964372.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4887110/pexels-photo-4887110.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Premium Cotton Filling",
        "4 Essential Pieces",
        "Gift-Ready Packaging",
        "Skin-Friendly Fabric",
        "Suitable for All Seasons",
      ],
      isFeatured: true,
      isBestseller: true,
      ageRange: "0-8 months",
      material: "Premium Cotton",
      rating: "4.9",
      reviewCount: 203,
    },
    {
      name: "5 Pcs Premium Combo Set",
      slug: "5-pcs-premium-combo-set",
      description:
        "The ultimate newborn combo! This 5-piece set includes a carry bed, sleeping mattress, shaped pillow, pair of bolsters, and a matching mosquito net. Everything a new parent needs, beautifully coordinated in soft pastel colors. Made from premium organic cotton that's gentle on sensitive newborn skin.",
      shortDescription: "Complete set with carry bed, mattress, pillow, bolsters & net",
      price: "4650.00",
      compareAtPrice: "4999.00",
      categoryId: comboSets.id,
      images: [
        "https://images.pexels.com/photos/4887156/pexels-photo-4887156.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4964372/pexels-photo-4964372.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4887081/pexels-photo-4887081.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Organic Cotton",
        "5 Essential Pieces",
        "Includes Mosquito Net",
        "Pastel Color Options",
        "Complete Newborn Solution",
      ],
      isFeatured: true,
      isBestseller: false,
      ageRange: "0-8 months",
      material: "Organic Cotton",
      rating: "4.7",
      reviewCount: 159,
    },
    // Carry Beds
    {
      name: "Carry Bed - Cloud Print",
      slug: "carry-bed-cloud-print",
      description:
        "A beautifully designed carry bed with an adorable cloud print, perfect for giving your baby a cozy and secure sleeping space. The lightweight design makes it easy to carry around the house or for travel. Features sturdy handles and a padded base for maximum comfort. The cotton fabric is soft, breathable, and machine washable.",
      shortDescription: "Portable cloud-print carry bed with handles",
      price: "900.00",
      compareAtPrice: null,
      categoryId: carryBeds.id,
      images: [
        "https://images.pexels.com/photos/33719889/pexels-photo-33719889.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/14023459/pexels-photo-14023459.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Sturdy Carry Handles",
        "Padded Base",
        "Lightweight Design",
        "Machine Washable",
        "Travel Friendly",
      ],
      isFeatured: false,
      isBestseller: true,
      ageRange: "0-6 months",
      material: "Cotton",
      rating: "4.5",
      reviewCount: 87,
    },
    {
      name: "Carry Bed - Teddy Bear",
      slug: "carry-bed-teddy-bear",
      description:
        "An adorable teddy bear themed carry bed that your baby will love. The raised sides provide a sense of security while the soft cotton base ensures comfort. Perfect for naps at home, visits to grandparents, or any time you need a portable sleeping solution. The cute teddy bear embroidery adds a charming touch.",
      shortDescription: "Teddy bear themed portable carry bed",
      price: "900.00",
      compareAtPrice: null,
      categoryId: carryBeds.id,
      images: [
        "https://images.pexels.com/photos/12654853/pexels-photo-12654853.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
        "https://images.pexels.com/photos/33719889/pexels-photo-33719889.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Raised Side Walls",
        "Teddy Bear Embroidery",
        "Soft Cotton Base",
        "Portable Design",
        "Perfect for Travel",
      ],
      isFeatured: true,
      isBestseller: false,
      ageRange: "0-6 months",
      material: "Cotton",
      rating: "4.4",
      reviewCount: 64,
    },
    // Cradle Sets
    {
      name: "Cradle Set - Floral Dreams",
      slug: "cradle-set-floral-dreams",
      description:
        "A gorgeous floral-print cradle set that transforms your baby's cradle into a cozy haven. Includes a fitted cradle sheet, pillow, and bumper. Made from premium cotton with beautiful floral prints in soft pastel colors. The elastic-edged sheet fits snugly on standard cradles, and the padded bumper provides extra protection.",
      shortDescription: "Floral cradle sheet, pillow & bumper set",
      price: "1550.00",
      compareAtPrice: "1999.00",
      categoryId: babyCradles.id,
      images: [
        "https://images.pexels.com/photos/4964372/pexels-photo-4964372.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4964488/pexels-photo-4964488.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Elastic-Edged Sheet",
        "Padded Bumper",
        "Fits Standard Cradles",
        "Soft Pastel Colors",
        "Premium Cotton",
      ],
      isFeatured: true,
      isBestseller: true,
      ageRange: "0-12 months",
      material: "Premium Cotton",
      rating: "4.8",
      reviewCount: 142,
    },
    {
      name: "Cradle Set - Safari Adventure",
      slug: "cradle-set-safari-adventure",
      description:
        "Bring a touch of adventure to your nursery with this safari-themed cradle set. Featuring adorable animal prints including lions, elephants, and giraffes. The set includes a soft cradle mattress, pillow, and protective bumpers. Made from breathable cotton that keeps your baby comfortable in all seasons.",
      shortDescription: "Safari-themed cradle mattress & bumper set",
      price: "1550.00",
      compareAtPrice: null,
      categoryId: babyCradles.id,
      images: [
        "https://images.pexels.com/photos/4964488/pexels-photo-4964488.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4964372/pexels-photo-4964372.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Cute Animal Prints",
        "Breathable Cotton",
        "All-Season Comfort",
        "Complete Cradle Set",
        "Easy to Install",
      ],
      isFeatured: false,
      isBestseller: false,
      ageRange: "0-12 months",
      material: "Cotton",
      rating: "4.6",
      reviewCount: 89,
    },
    // Feeding Pillows
    {
      name: "Feeding Pillow - Lavender",
      slug: "feeding-pillow-lavender",
      description:
        "An ergonomically designed feeding pillow in a soothing lavender shade. This C-shaped pillow wraps around your waist, providing excellent support during breastfeeding or bottle-feeding. The removable, washable cover makes maintenance easy. The firm yet comfortable filling maintains its shape and provides consistent support session after session.",
      shortDescription: "Ergonomic C-shaped feeding support pillow",
      price: "850.00",
      compareAtPrice: "1200.00",
      categoryId: feedingPillows.id,
      images: [
        "https://images.pexels.com/photos/4887110/pexels-photo-4887110.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4887081/pexels-photo-4887081.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Ergonomic C-Shape",
        "Removable Washable Cover",
        "Maintains Shape",
        "Waist Support Design",
        "Firm Comfortable Filling",
      ],
      isFeatured: true,
      isBestseller: true,
      ageRange: "0-12 months",
      material: "Cotton with Polyester Fill",
      rating: "4.8",
      reviewCount: 234,
    },
    {
      name: "Feeding Pillow - Mint Green",
      slug: "feeding-pillow-mint-green",
      description:
        "A fresh mint green feeding pillow designed to make feeding time comfortable for both mom and baby. Features a unique contoured shape that positions baby at the perfect angle. The anti-slip base keeps the pillow securely in place while the soft cotton cover is gentle against baby's skin.",
      shortDescription: "Contoured mint green feeding pillow with anti-slip base",
      price: "850.00",
      compareAtPrice: "1200.00",
      categoryId: feedingPillows.id,
      images: [
        "https://images.pexels.com/photos/4887081/pexels-photo-4887081.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4887110/pexels-photo-4887110.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Contoured Shape",
        "Anti-Slip Base",
        "Perfect Feeding Angle",
        "Soft Cotton Cover",
        "Easy to Carry",
      ],
      isFeatured: false,
      isBestseller: false,
      ageRange: "0-12 months",
      material: "Cotton with Polyester Fill",
      rating: "4.6",
      reviewCount: 112,
    },
    // Hooded Towels
    {
      name: "Hooded Towel - Bunny Ears",
      slug: "hooded-towel-bunny-ears",
      description:
        "The most adorable bath time companion! This hooded towel features cute bunny ears and is made from ultra-soft, highly absorbent muslin cotton. Generously sized to wrap your baby snugly after bath time. The hood keeps baby's head warm while the towel absorbs water quickly. A perfect baby shower gift!",
      shortDescription: "Adorable bunny ears hooded bath towel",
      price: "399.00",
      compareAtPrice: "599.00",
      categoryId: hoodedTowels.id,
      images: [
        "https://images.pexels.com/photos/16222075/pexels-photo-16222075.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
        "https://images.pexels.com/photos/15427723/pexels-photo-15427723.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      ],
      features: [
        "Cute Bunny Ears Design",
        "Ultra-Soft Muslin Cotton",
        "Highly Absorbent",
        "Generous Size",
        "Perfect Gift Item",
      ],
      isFeatured: true,
      isBestseller: true,
      ageRange: "0-24 months",
      material: "Muslin Cotton",
      rating: "4.9",
      reviewCount: 312,
    },
    {
      name: "Hooded Towel - Bear Cub",
      slug: "hooded-towel-bear-cub",
      description:
        "Transform bath time into fun time with this cute bear cub hooded towel. Made from 100% organic cotton terry that's incredibly soft and absorbent. The double-layered hood provides extra warmth and features an adorable bear face with embroidered details. Available in neutral colors perfect for boys and girls.",
      shortDescription: "Organic cotton bear cub hooded towel",
      price: "399.00",
      compareAtPrice: "599.00",
      categoryId: hoodedTowels.id,
      images: [
        "https://images.pexels.com/photos/15427723/pexels-photo-15427723.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
        "https://images.pexels.com/photos/16222075/pexels-photo-16222075.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      ],
      features: [
        "Organic Cotton Terry",
        "Double-Layered Hood",
        "Embroidered Bear Face",
        "Gender Neutral Colors",
        "Super Absorbent",
      ],
      isFeatured: false,
      isBestseller: true,
      ageRange: "0-24 months",
      material: "Organic Cotton Terry",
      rating: "4.7",
      reviewCount: 187,
    },
    // Bedding Combo
    {
      name: "Bedding Combo - Royal Collection",
      slug: "bedding-combo-royal-collection",
      description:
        "Our premium Royal Collection bedding combo includes a quilted mattress, shaped head pillow, two bolsters, and a soft blanket. Each piece is crafted from the finest cotton with exquisite embroidery detailing. The mattress features multi-layer padding for optimal support. This luxurious set makes a perfect gift for new parents who want nothing but the best for their little one.",
      shortDescription: "Premium 5-piece quilted bedding set with embroidery",
      price: "4799.00",
      compareAtPrice: "5999.00",
      categoryId: babyBedding.id,
      images: [
        "https://images.pexels.com/photos/4964488/pexels-photo-4964488.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4964372/pexels-photo-4964372.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4887156/pexels-photo-4887156.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Finest Cotton Fabric",
        "Exquisite Embroidery",
        "Multi-Layer Padding",
        "5 Essential Pieces",
        "Luxury Gift Packaging",
      ],
      isFeatured: true,
      isBestseller: true,
      ageRange: "0-12 months",
      material: "Premium Cotton",
      rating: "4.9",
      reviewCount: 256,
    },
    // Baby Wrapper
    {
      name: "Baby Wrapper - Soft Pink",
      slug: "baby-wrapper-soft-pink",
      description:
        "A luxuriously soft baby wrapper in a delicate pink shade. Made from premium velvet-touch cotton that's incredibly gentle on newborn skin. Features a convenient hook-and-loop closure for easy swaddling. The wrapper helps recreate the womb-like feeling, helping your baby sleep more peacefully. Perfect for all seasons with its breathable yet warm fabric.",
      shortDescription: "Velvet-touch cotton wrapper with easy closure",
      price: "850.00",
      compareAtPrice: "1200.00",
      categoryId: swaddlesWrappers.id,
      images: [
        "https://images.pexels.com/photos/11517555/pexels-photo-11517555.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
        "https://images.pexels.com/photos/12654853/pexels-photo-12654853.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      ],
      features: [
        "Velvet-Touch Cotton",
        "Hook-and-Loop Closure",
        "Womb-Like Comfort",
        "All-Season Fabric",
        "Easy Swaddling",
      ],
      isFeatured: true,
      isBestseller: true,
      ageRange: "0-4 months",
      material: "Velvet Cotton",
      rating: "4.7",
      reviewCount: 198,
    },
    {
      name: "Baby Wrapper - Sky Blue",
      slug: "baby-wrapper-sky-blue",
      description:
        "A beautiful sky blue baby wrapper for your little prince. Crafted from organic cotton that's free from harmful chemicals. The stretchy fabric allows natural movement while keeping baby secure. Features a unique design that grows with your baby, usable from newborn to 6 months.",
      shortDescription: "Organic cotton stretchy wrapper in sky blue",
      price: "850.00",
      compareAtPrice: "1200.00",
      categoryId: swaddlesWrappers.id,
      images: [
        "https://images.pexels.com/photos/12654853/pexels-photo-12654853.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
        "https://images.pexels.com/photos/11517555/pexels-photo-11517555.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      ],
      features: [
        "Organic Cotton",
        "Chemical Free",
        "Stretchy Fabric",
        "Grows with Baby",
        "Secure Fit",
      ],
      isFeatured: false,
      isBestseller: false,
      ageRange: "0-6 months",
      material: "Organic Cotton",
      rating: "4.5",
      reviewCount: 134,
    },
    // Net Beds
    {
      name: "Net Bed - Princess Pink",
      slug: "net-bed-princess-pink",
      description:
        "Keep your baby protected and comfortable with this beautiful pink net bed. Features a foldable mosquito net that provides complete protection from insects while allowing fresh air circulation. The padded mattress base ensures comfort, and the entire unit folds flat for easy storage and portability.",
      shortDescription: "Foldable net bed with padded mattress base",
      price: "1299.00",
      compareAtPrice: "1599.00",
      categoryId: netBeds.id,
      images: [
        "https://images.pexels.com/photos/4887156/pexels-photo-4887156.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/14023459/pexels-photo-14023459.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Foldable Mosquito Net",
        "Padded Mattress Base",
        "Insect Protection",
        "Air Circulation Design",
        "Easy Storage",
      ],
      isFeatured: true,
      isBestseller: false,
      ageRange: "0-12 months",
      material: "Cotton & Net",
      rating: "4.6",
      reviewCount: 156,
    },
    {
      name: "Net Bed - Ocean Blue",
      slug: "net-bed-ocean-blue",
      description:
        "A spacious ocean blue net bed with an attractive print and durable construction. The pop-up net design makes it incredibly easy to set up and fold down. Features a thick padded base for comfort and mesh sides for visibility and ventilation. Includes a small pillow and side bolsters for added comfort.",
      shortDescription: "Pop-up net bed with thick padded base",
      price: "1299.00",
      compareAtPrice: "1599.00",
      categoryId: netBeds.id,
      images: [
        "https://images.pexels.com/photos/14023459/pexels-photo-14023459.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/33719889/pexels-photo-33719889.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Pop-Up Design",
        "Thick Padded Base",
        "Mesh Side Panels",
        "Includes Pillow & Bolsters",
        "Durable Construction",
      ],
      isFeatured: false,
      isBestseller: true,
      ageRange: "0-12 months",
      material: "Cotton & Mesh",
      rating: "4.5",
      reviewCount: 98,
    },
    // Jablas & Clothing
    {
      name: "Muslin Jabla Set - Pack of 6",
      slug: "muslin-jabla-set-pack-6",
      description:
        "A pack of 6 premium muslin jablas in assorted prints and colors. These traditional Indian baby garments are perfect for everyday wear, offering maximum comfort and ease. The front-tie design makes dressing easy, and the breathable muslin fabric keeps baby cool in warm weather. Becomes softer with every wash.",
      shortDescription: "Pack of 6 assorted muslin jablas with front tie",
      price: "699.00",
      compareAtPrice: "999.00",
      categoryId: jablasClothing.id,
      images: [
        "https://images.pexels.com/photos/32386177/pexels-photo-32386177.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/8773748/pexels-photo-8773748.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Pack of 6",
        "Assorted Prints",
        "Front-Tie Design",
        "Breathable Muslin",
        "Gets Softer with Wash",
      ],
      isFeatured: false,
      isBestseller: true,
      ageRange: "0-6 months",
      material: "Muslin Cotton",
      rating: "4.6",
      reviewCount: 289,
    },
    {
      name: "Newborn Cap & Mitten Set",
      slug: "newborn-cap-mitten-set",
      description:
        "An essential set of soft cotton caps and mittens for your newborn. Includes 3 caps and 3 pairs of mittens in adorable pastel colors. The caps provide warmth and protection for baby's delicate head, while the mittens prevent scratching. Made from 100% organic cotton that's gentle on sensitive skin.",
      shortDescription: "3 caps & 3 mitten pairs in organic cotton",
      price: "399.00",
      compareAtPrice: "549.00",
      categoryId: jablasClothing.id,
      images: [
        "https://images.pexels.com/photos/8773748/pexels-photo-8773748.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/32386177/pexels-photo-32386177.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "3 Caps + 3 Mitten Pairs",
        "Organic Cotton",
        "Anti-Scratch Mittens",
        "Pastel Colors",
        "Gentle on Skin",
      ],
      isFeatured: false,
      isBestseller: false,
      ageRange: "0-3 months",
      material: "Organic Cotton",
      rating: "4.4",
      reviewCount: 167,
    },
    // Muslin Collection
    {
      name: "Muslin Swaddle Blanket - Large",
      slug: "muslin-swaddle-blanket-large",
      description:
        "An extra-large muslin swaddle blanket measuring 47x47 inches, perfect for swaddling, nursing cover, stroller blanket, or tummy time mat. Made from 100% premium muslin cotton with a beautiful floral print. The lightweight, breathable fabric is perfect for all seasons and becomes incredibly soft with each wash.",
      shortDescription: "47x47 inch premium muslin multi-use blanket",
      price: "599.00",
      compareAtPrice: "799.00",
      categoryId: muslinCollection.id,
      images: [
        "https://images.pexels.com/photos/8773748/pexels-photo-8773748.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/11517555/pexels-photo-11517555.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      ],
      features: [
        "Extra Large 47x47 inches",
        "Multi-Purpose Use",
        "Premium Muslin Cotton",
        "All-Season Comfort",
        "Gets Softer with Wash",
      ],
      isFeatured: true,
      isBestseller: true,
      ageRange: "0-18 months",
      material: "Muslin Cotton",
      rating: "4.8",
      reviewCount: 345,
    },
    {
      name: "Muslin Washcloth Set - Pack of 6",
      slug: "muslin-washcloth-set-6",
      description:
        "A set of 6 ultra-soft muslin washcloths perfect for baby's daily cleaning routine. Use for wiping face, hands, or as a burp cloth. The natural muslin fabric is incredibly gentle on baby's sensitive skin and highly absorbent. Each cloth features a different adorable print.",
      shortDescription: "6-pack ultra-soft muslin baby washcloths",
      price: "349.00",
      compareAtPrice: "499.00",
      categoryId: muslinCollection.id,
      images: [
        "https://images.pexels.com/photos/32386177/pexels-photo-32386177.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/8773748/pexels-photo-8773748.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Pack of 6",
        "Ultra-Soft Muslin",
        "Multi-Use Design",
        "Highly Absorbent",
        "Different Prints",
      ],
      isFeatured: false,
      isBestseller: false,
      ageRange: "0-24 months",
      material: "Muslin Cotton",
      rating: "4.5",
      reviewCount: 156,
    },
    // Storage Baskets
    {
      name: "Cotton Rope Storage Basket - Set of 3",
      slug: "cotton-rope-storage-basket-set-3",
      description:
        "A beautiful set of 3 cotton rope baskets in graduated sizes, perfect for organizing your nursery. Use them to store diapers, towels, toys, and all baby essentials. The natural cotton rope construction is sturdy yet soft, with reinforced handles for easy carrying. These versatile baskets also make gorgeous decor pieces.",
      shortDescription: "3-piece natural cotton rope nursery organizer set",
      price: "1299.00",
      compareAtPrice: "1799.00",
      categoryId: storageBasket.id,
      images: [
        "https://images.pexels.com/photos/4964374/pexels-photo-4964374.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4964372/pexels-photo-4964372.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Set of 3 Graduated Sizes",
        "Natural Cotton Rope",
        "Reinforced Handles",
        "Multi-Purpose Storage",
        "Doubles as Decor",
      ],
      isFeatured: true,
      isBestseller: false,
      ageRange: "All Ages",
      material: "Cotton Rope",
      rating: "4.7",
      reviewCount: 89,
    },
    {
      name: "Diaper Caddy Organizer",
      slug: "diaper-caddy-organizer",
      description:
        "Keep all your diaper changing essentials organized with this premium diaper caddy. Features multiple compartments for diapers, wipes, creams, and more. The removable dividers let you customize the layout. Sturdy handles make it easy to carry from room to room. Made from durable, washable cotton canvas.",
      shortDescription: "Multi-compartment portable diaper organizer",
      price: "899.00",
      compareAtPrice: "1199.00",
      categoryId: storageBasket.id,
      images: [
        "https://images.pexels.com/photos/4964372/pexels-photo-4964372.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4964374/pexels-photo-4964374.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Multiple Compartments",
        "Removable Dividers",
        "Portable Design",
        "Washable Canvas",
        "Sturdy Handles",
      ],
      isFeatured: false,
      isBestseller: true,
      ageRange: "All Ages",
      material: "Cotton Canvas",
      rating: "4.6",
      reviewCount: 134,
    },
    // Newborn Essentials
    {
      name: "Newborn Welcome Kit",
      slug: "newborn-welcome-kit",
      description:
        "The perfect welcome gift for a newborn! This comprehensive kit includes 2 jablas, 1 cap, 1 pair of mittens, 1 pair of booties, 1 swaddle wrapper, and 1 receiving blanket. Everything is made from the softest organic cotton in gender-neutral colors. Beautifully packaged in a keepsake box that parents will treasure.",
      shortDescription: "Complete organic cotton newborn starter kit",
      price: "2499.00",
      compareAtPrice: "2999.00",
      categoryId: newbornEssentials.id,
      images: [
        "https://images.pexels.com/photos/12654853/pexels-photo-12654853.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
        "https://images.pexels.com/photos/32386177/pexels-photo-32386177.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/8773748/pexels-photo-8773748.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "7 Essential Items",
        "Organic Cotton",
        "Gender Neutral Colors",
        "Keepsake Box Packaging",
        "Perfect Gift Set",
      ],
      isFeatured: true,
      isBestseller: true,
      ageRange: "0-3 months",
      material: "Organic Cotton",
      rating: "4.9",
      reviewCount: 412,
    },
    {
      name: "Baby Nappy Set - Pack of 12",
      slug: "baby-nappy-set-12",
      description:
        "A value pack of 12 premium cotton nappies in assorted colors. These traditional cloth nappies are ultra-absorbent, reusable, and environmentally friendly. Made from triple-layered muslin cotton for maximum absorption. Easy to wash and quick-drying, these nappies are a nursery essential every parent needs.",
      shortDescription: "12-pack reusable triple-layer muslin nappies",
      price: "599.00",
      compareAtPrice: "899.00",
      categoryId: newbornEssentials.id,
      images: [
        "https://images.pexels.com/photos/32386177/pexels-photo-32386177.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/8773748/pexels-photo-8773748.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Pack of 12",
        "Triple-Layer Muslin",
        "Ultra-Absorbent",
        "Reusable & Eco-Friendly",
        "Quick Drying",
      ],
      isFeatured: false,
      isBestseller: true,
      ageRange: "0-12 months",
      material: "Muslin Cotton",
      rating: "4.5",
      reviewCount: 567,
    },
    // More Bedding
    {
      name: "Baby Gadda Set - Sunshine Yellow",
      slug: "baby-gadda-set-sunshine-yellow",
      description:
        "A cheerful sunshine yellow gadda (mattress) set that brings warmth and brightness to your nursery. This traditional Indian baby mattress is well-padded with recron fill and covered in soft cotton. Includes matching pillow and two bolsters. The vibrant yellow color with cute sun and cloud prints will make your baby's sleeping space a happy place.",
      shortDescription: "Padded gadda with matching pillow & bolsters",
      price: "1299.00",
      compareAtPrice: "1699.00",
      categoryId: babyBedding.id,
      images: [
        "https://images.pexels.com/photos/4964374/pexels-photo-4964374.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/4964488/pexels-photo-4964488.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      ],
      features: [
        "Recron Fill Padding",
        "Soft Cotton Cover",
        "Matching Set",
        "Vibrant Prints",
        "Comfortable Support",
      ],
      isFeatured: false,
      isBestseller: false,
      ageRange: "0-8 months",
      material: "Cotton with Recron Fill",
      rating: "4.4",
      reviewCount: 78,
    },
    {
      name: "Muslin Blanket - Pack of 3",
      slug: "muslin-blanket-pack-3",
      description:
        "A set of 3 large muslin blankets in beautiful pastel shades - pink, blue, and mint green. Each blanket is made from 6 layers of premium muslin cotton, making them incredibly soft, warm, yet breathable. Perfect as a blanket, stroller cover, nursing cover, or play mat. These versatile blankets are a must-have for every parent.",
      shortDescription: "3-pack 6-layer muslin blankets in pastel shades",
      price: "1199.00",
      compareAtPrice: "1599.00",
      categoryId: muslinCollection.id,
      images: [
        "https://images.pexels.com/photos/8773748/pexels-photo-8773748.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        "https://images.pexels.com/photos/11517555/pexels-photo-11517555.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
      ],
      features: [
        "Pack of 3",
        "6-Layer Premium Muslin",
        "Pastel Shades",
        "Multi-Purpose Use",
        "Incredibly Soft",
      ],
      isFeatured: true,
      isBestseller: true,
      ageRange: "0-24 months",
      material: "Muslin Cotton",
      rating: "4.8",
      reviewCount: 234,
    },
  ];

  const insertedProducts = await db
    .insert(products)
    .values(productData)
    .returning();

  // Add reviews
  const reviewsData: Array<{
    productId: number;
    authorName: string;
    rating: number;
    title: string;
    body: string;
    verified: boolean;
  }> = [];

  const reviewTemplates = [
    {
      authorName: "Priya Sharma",
      rating: 5,
      title: "Absolutely love it!",
      body: "The quality is amazing and my baby loves it. The fabric is so soft and gentle. Highly recommended for all new parents!",
    },
    {
      authorName: "Anita Desai",
      rating: 5,
      title: "Best purchase ever",
      body: "I've bought many baby products but this one stands out. The material quality is premium and it's exactly as shown in the pictures.",
    },
    {
      authorName: "Ravi Kumar",
      rating: 4,
      title: "Great value for money",
      body: "Good quality product at a reasonable price. My wife is very happy with this purchase. Delivery was also quick.",
    },
    {
      authorName: "Sneha Patel",
      rating: 5,
      title: "Perfect gift for newborn",
      body: "Bought this as a gift for my sister's baby. She absolutely loved it! The packaging was beautiful too. Will definitely buy again.",
    },
    {
      authorName: "Mohammed Rafi",
      rating: 4,
      title: "Soft and comfortable",
      body: "The cotton is very soft and breathable. My baby sleeps peacefully. Only giving 4 stars because delivery took a bit longer than expected.",
    },
    {
      authorName: "Deepa Nair",
      rating: 5,
      title: "Exceeded expectations",
      body: "The quality exceeded my expectations. The stitching is neat, the fabric is premium, and the design is beautiful. My baby's skin is very sensitive but this product caused no irritation.",
    },
    {
      authorName: "Amit Verma",
      rating: 4,
      title: "Very good quality",
      body: "Nice product, good quality. My baby seems comfortable. Worth the price. Would recommend to other parents.",
    },
    {
      authorName: "Kavita Reddy",
      rating: 5,
      title: "Must-have for new parents",
      body: "This is a must-have! The quality is outstanding and it's so practical. I use it every day. Best baby product I've purchased.",
    },
    {
      authorName: "Suresh Iyer",
      rating: 5,
      title: "Superb quality",
      body: "Bought for our newborn and couldn't be happier. The softness is incredible and it washes beautifully. Even after multiple washes, the quality remains.",
    },
    {
      authorName: "Lakshmi Menon",
      rating: 4,
      title: "Really nice product",
      body: "Very happy with this purchase. The colors are beautiful and the cotton is soft. Would have given 5 stars if there were more color options.",
    },
  ];

  for (const product of insertedProducts) {
    const numReviews = Math.floor(Math.random() * 4) + 3;
    const shuffled = [...reviewTemplates].sort(() => Math.random() - 0.5);
    for (let i = 0; i < numReviews; i++) {
      reviewsData.push({
        productId: product.id,
        ...shuffled[i],
        verified: true,
      });
    }
  }

  await db.insert(reviews).values(reviewsData);

  console.log(
    `✅ Seeded ${insertedProducts.length} products across categories with reviews!`
  );
}

seed()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("Seed failed:", err);
    process.exit(1);
  });
