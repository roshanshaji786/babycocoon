"use client";

import { create } from "zustand";

export interface CartItem {
  id: number;
  name: string;
  price: number;
  compareAtPrice: number | null;
  image: string;
  slug: string;
  quantity: number;
}

interface CartState {
  items: CartItem[];
  isOpen: boolean;
  hydrated: boolean;
  openCart: () => void;
  closeCart: () => void;
  toggleCart: () => void;
  addItem: (item: Omit<CartItem, "quantity">) => void;
  removeItem: (id: number) => void;
  updateQuantity: (id: number, quantity: number) => void;
  clearCart: () => void;
  hydrate: () => void;
}

function loadCartFromStorage(): CartItem[] {
  if (typeof window === "undefined") return [];
  try {
    const stored = localStorage.getItem("babycocoon-cart");
    if (stored) return JSON.parse(stored);
  } catch {
    // ignore
  }
  return [];
}

function saveCartToStorage(items: CartItem[]) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem("babycocoon-cart", JSON.stringify(items));
  } catch {
    // ignore
  }
}

export const useCartStore = create<CartState>((set) => ({
  items: [],
  isOpen: false,
  hydrated: false,

  hydrate: () => {
    const items = loadCartFromStorage();
    set({ items, hydrated: true });
  },

  openCart: () => set({ isOpen: true }),
  closeCart: () => set({ isOpen: false }),
  toggleCart: () => set((state) => ({ isOpen: !state.isOpen })),

  addItem: (item) =>
    set((state) => {
      const existing = state.items.find((i) => i.id === item.id);
      let newItems: CartItem[];
      if (existing) {
        newItems = state.items.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      } else {
        newItems = [...state.items, { ...item, quantity: 1 }];
      }
      saveCartToStorage(newItems);
      return { items: newItems, isOpen: true };
    }),

  removeItem: (id) =>
    set((state) => {
      const newItems = state.items.filter((i) => i.id !== id);
      saveCartToStorage(newItems);
      return { items: newItems };
    }),

  updateQuantity: (id, quantity) =>
    set((state) => {
      if (quantity < 1) {
        const newItems = state.items.filter((i) => i.id !== id);
        saveCartToStorage(newItems);
        return { items: newItems };
      }
      const newItems = state.items.map((i) =>
        i.id === id ? { ...i, quantity } : i
      );
      saveCartToStorage(newItems);
      return { items: newItems };
    }),

  clearCart: () => {
    saveCartToStorage([]);
    set({ items: [] });
  },
}));

// Selectors (not methods to avoid stale closure issues)
export function getCartTotalItems(items: CartItem[]): number {
  return items.reduce((acc, i) => acc + i.quantity, 0);
}

export function getCartSubtotal(items: CartItem[]): number {
  return items.reduce((acc, i) => acc + i.price * i.quantity, 0);
}
